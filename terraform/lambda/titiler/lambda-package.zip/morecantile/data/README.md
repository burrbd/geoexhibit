# tileMatrixSet json documents

TileMatrixSet from https://schemas.opengis.net/tms/2.0/json/examples/tilematrixset/

`NZTM2000` and `LINZAntarticaMapTilegrid` are from GDAL https://github.com/OSGeo/gdal/pull/2505/files#diff-33251b8c7db3e78835102ded8d11d851
